
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-br" lang="pt-br">

<head>
  <base href="http://www.movimentohermes.com.br/index.php" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="ceue, hermes, movimento hermes, chapa hermes, ufrgs, eleições, 2010, 2011, engenharia" />
  <meta name="description" content="Movimento Hermes" />
  <meta name="generator" content="Joomla! 1.5 - Open Source Content Management" />
  <title>Chapa 1 do CEUE: Hermes</title>
  <link href="/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link href="/templates/ja_pyro/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <link rel="stylesheet" href="/plugins/content/ja_tabs/ja.tabs.css" type="text/css" />
  <link rel="stylesheet" href="/modules/mod_jatwitter/assets/style.css" type="text/css" />
  <link rel="stylesheet" href="http://www.movimentohermes.com.br/modules/mod_ja_contentslide/assets/css/ja_contentslide.css" type="text/css" />
  <link rel="stylesheet" href="http://www.movimentohermes.com.br/templates/ja_pyro/css/ja_contentslide.css" type="text/css" />
  <link rel="stylesheet" href="/modules/mod_jaslideshow2/assets/style.css" type="text/css" />
  <link rel="stylesheet" href="/templates/ja_pyro/css/mod_jaslideshow2.css" type="text/css" />
  <script type="text/javascript" src="/media/system/js/mootools.js"></script>
  <script type="text/javascript" src="/media/system/js/caption.js"></script>
  <script type="text/javascript" src="/plugins/content/ja_tabs/ja.tabs.js"></script>
  <script type="text/javascript" src="http://www.movimentohermes.com.br/modules/mod_ja_contentslide/assets/js/ja_contentslide.js"></script>
  <script type="text/javascript" src="/modules/mod_jaslideshow2/assets/script.js"></script>
  <!-- JoomlaWorks "AllVideos" Plugin (v3.3) starts here -->

		
		

<style type="text/css" media="all">
	@import "http://www.movimentohermes.com.br/plugins/content/jw_allvideos/tmpl/css/template.css";
</style>
		
<script type="text/javascript" src="http://www.movimentohermes.com.br/plugins/content/jw_allvideos/includes/players/wmvplayer/silverlight.js"></script>
<script type="text/javascript" src="http://www.movimentohermes.com.br/plugins/content/jw_allvideos/includes/players/wmvplayer/wmvplayer.js"></script>
<script type="text/javascript" src="http://www.movimentohermes.com.br/plugins/content/jw_allvideos/includes/players/quicktimeplayer/AC_QuickTime.js"></script>
<script type="text/javascript" src="http://www.movimentohermes.com.br/plugins/content/jw_allvideos/includes/jw_allvideos.js"></script>
			
<script type="text/javascript">
	//<![CDATA[
	window.addEvent('domready', function() {
		AllVideosLightBox.Init({
			AVLBWidth:800,
			AVLBHeight:600
		});
		AllVideosEmbed.Init();
	});
	//]]>
</script>
			
<!-- JoomlaWorks "AllVideos" Plugin (v3.3) ends here -->


<link rel="stylesheet" href="http://www.movimentohermes.com.br/templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="http://www.movimentohermes.com.br/templates/system/css/general.css" type="text/css" />
<link rel="stylesheet" href="http://www.movimentohermes.com.br/templates/ja_pyro/css/addons.css" type="text/css" />
<link rel="stylesheet" href="http://www.movimentohermes.com.br/templates/ja_pyro/css/layout.css" type="text/css" />
<link rel="stylesheet" href="http://www.movimentohermes.com.br/templates/ja_pyro/css/template.css" type="text/css" />
<link rel="stylesheet" href="http://www.movimentohermes.com.br/templates/ja_pyro/css/typo.css" type="text/css" />

<!--[if IE]>
<link rel="stylesheet" href="http://www.movimentohermes.com.br/templates/ja_pyro/css/ie.css" type="text/css" />
<![endif]-->

<!--[if lt IE 7.0]>
<link rel="stylesheet" href="http://www.movimentohermes.com.br/templates/ja_pyro/css/ie7minus.css" type="text/css" />
<style type="text/css">
.main { width: expression(document.body.clientWidth < 770? "770px" : document.body.clientWidth > 1200? "1200px" : "auto"); }
</style>
<![endif]-->

<!--[if IE 7.0]>
<style type="text/css">
.clearfix { display: inline-block; } /* IE7xhtml*/
</style>
<![endif]-->

<script type="text/javascript">
var siteurl='http://www.movimentohermes.com.br/';
var tmplurl='http://www.movimentohermes.com.br/templates/ja_pyro';
</script>

<script language="javascript" type="text/javascript" src="http://www.movimentohermes.com.br/templates/ja_pyro/js/ja.script.js"></script>
<script language="javascript" type="text/javascript" src="http://www.movimentohermes.com.br/templates/ja_pyro/js/ja.ddmod.js"></script>


<link href="http://www.movimentohermes.com.br/templates/ja_pyro/css/menu/mega.css" rel="stylesheet" type="text/css" /><script src="http://www.movimentohermes.com.br/templates/ja_pyro/js/menu/mega.js" language="javascript" type="text/javascript"></script>
<link href="http://www.movimentohermes.com.br/templates/ja_pyro/css/colors/default.css" rel="stylesheet" type="text/css" />



<!--Width of template -->
<style type="text/css">
.main {width: 965px;margin: 0 auto;}
#ja-wrapper {min-width: 966px;}
</style>


<!--Update width for mainnav -->
<script type="text/javascript">
//<![CDATA[
window.addEvent ('domready', function () {
	if ($E('#ja-mainnav .inner') && $E('#ja-mainnav ul').offsetWidth) {
		$E('#ja-mainnav .inner').setStyle ('width', $E('#ja-mainnav ul').offsetWidth);
	}
});
//]]>
</script><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-478966-17']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body id="bd" class="fs4 Others">

<div id="ja-wrapper" class="ja-home">
	<a name="Top" id="Top"></a>

	<!-- HEADER -->
	<div id="ja-header" class="wrap">
<div class="main clearfix">

		<h1 class="logo">
		<a href="/index.php" title="Chapa 1 do CEUE: Hermes"><span>Chapa 1 do CEUE: Hermes</span></a>
	</h1>
		
		
</div>
</div>
	<!-- //HEADER -->

	<!-- MAIN CONTAINER -->
	
	
	
	<div id="ja-container" class="wrap ja-r1">
	<div class="main clearfix">
	
	<div class="ja-rs-top"><div class="ja-rs-tl">&nbsp;</div><div class="ja-rs-tr">&nbsp;</div></div>
	<div class="ja-rs-mid"><div class="ja-rs-ml"><div class="ja-rs-mr">
	<div class="ja-rs-content clearfix">
		
		<!-- MAIN NAVIGATION -->
		<div id="ja-mainnav" class="clearfix">
<div class="inner">
	<div class="ja-megamenu">
<ul class="megamenu level0"><li class="mega active first"><a href="http://www.movimentohermes.com.br/" class="mega active first" id="menu1" title="Inicio"><span class="menu-title">Inicio</span></a></li><li class="mega"><a href="/diretorias.html" class="mega" id="menu148" title="Diretorias"><span class="menu-title">Diretorias</span></a></li><li class="mega"><a href="/projetos.html" class="mega" id="menu137" title="Projetos"><span class="menu-title">Projetos</span></a></li><li class="mega"><a href="http://www.movimentohermes.com.br/tudo" class="mega" id="menu147" title="Tudo"><span class="menu-title">Tudo</span></a></li><li class="mega"><a href="/acoes.html" class="mega" id="menu161" title="Ações"><span class="menu-title">Ações</span></a></li><li class="mega last"><a href="/faca-parte.html" class="mega last" id="menu138" title="Faça parte!"><span class="menu-title">Faça parte!</span></a></li></ul>
</div>			<script type="text/javascript">
			var megamenu = new jaMegaMenuMoo ('ja-mainnav', {
				'bgopacity': 0, 
				'delayHide': 1000, 
				'slide': 1, 
				'fading': 0,
				'direction':'down',
				'action':'mouseover',
				'tips': false,
				'duration': 300,
				'hidestyle': 'fastwhenshow'
			});			
			</script>
				
</div>
</div>


<ul class="no-display">
    <li><a href="/index.php#ja-content" title="Skip to content">Skip to content</a></li>
</ul>
		<!-- //MAIN NAVIGATION -->
	
		<div id="ja-top" class="clearfix">
  		<div class="ja-moduletable moduletable  clearfix" id="Mod88">
						<div class="ja-box-ct clearfix">
		
<div class="ja-slidewrap ja-articles" id="ja-slide-articles-88" style="visibility:hidden">
  
  <div class="ja-slide-main-wrap">
   <div class="ja-slide-mask">
  </div>
    <div class="ja-slide-main">
            <div class="ja-slide-item">
            	        	<div class="ja-slide-desc"> 
			 <a target="_parent"  href="/component/content/article/demo-slideshow/hermes.html">
			 	<span>Sobre Hermes
</span>
             </a>
			 
			 			  
			  <h4>Hermes</h4><h5>Se engenharia otimiza processos, por que não o conhecimento? Ainda mais de forma prática?</h5>              <p> 
Movimento Hermes é o nome dado ao grupo de pessoas focadas na otimização do conhecimento e de ações práticas. Basea-se no fato de que pessoas de bom carater, se souberem como algo pode ser feito e concluirem por si só por que tal ação deveria ser feita, esta será feita, e da melhor forma possível.
Atualmente, por maior parte de seus integrantes serem alunos da Escola de Engenharia e que, ou durante 2010 inteira, ou em algum momento, colaboraram na pratica para a reconstrução do CEUE, também concorrem as eleições deste centro acadêmico.
 
</p>
			            </div>  
		      </div>						
            <div class="ja-slide-item">
            	        	<div class="ja-slide-desc"> 
			 <a target="_parent"  href="/component/content/article/demo-slideshow/quem-somos.html">
			 	<span>Quem somos
</span>
             </a>
			 
			 			  
			  <h4>Idealistas? Sim</h4><h5>Quando se aprende o funcionamento de algo, você entende como poderia ser melhor</h5>              <p>Pessoas diferentes, tem perfis diferentes, mas em uma organização são necessárias. No Hermes, tanto burocratas quanto despojados são bem-vindos, trabalhando com o que mais gosta, e pelo aquilo que acredita dentro do sistema. Afinal, somos todos alunos de engenharia e futuros engenheiros, por que não estender isso também a um Centro Acadêmico?
</p>
			            </div>  
		      </div>						
            <div class="ja-slide-item">
            	        	<div class="ja-slide-desc"> 
			 <a target="_parent"  href="/component/content/article/demo-slideshow/por-que-nos.html">
			 	<span>Por que nós?
</span>
             </a>
			 
			 			  
			  <h4>Por que devemos ser os escolhidos?</h4><h5>O que nos diferencia dos demais?</h5>              <p>Mais do que promessas, somos práticos. Somos um grupo crescente, nascido da Escola de Engenharia, independentes, sem vínculo a grupos externos, como partidos. E acreditamos em um CEUE para os estudantes de agora, para o futuro, atuando também na sociedade que nos cerca. Se nos perguntarem 'Por que querem fazer tais projetos?', retrucaremos 'por que não fazer tais projetos?'. Pense a respeito.
</p>
			            </div>  
		      </div>						
            <div class="ja-slide-item">
      <img  src="/images/stories/demo/slideshow/sl-4.png" alt="Faça parte!" title="Faça parte!"   />      	        	<div class="ja-slide-desc"> 
			 <a target="_parent"  href="/component/content/article/demo-slideshow/faca-parte.html">
			 	<span>Faça parte!
</span>
             </a>
			 
			 			  
			  <h4>Um sonho não se realiza sem trabalho</h4><h5>Quanto mais gente organizada, melhor e mais rápido se chega ao sonho!</h5>              <p>Se você achou interessante algum projeto, os pensamentos da chapa ou tiver qualquer dúvida, crítica ou sugestão, entre em contato pelo e-mail contato[arroba]movimentohermes.com.br.
Para fazer parte deste movimento, entre em contato pelo mesmo e-mail, marque uma reunião ou converse com os membros. Estamos abertos a novas visões para abrangir mais e mais os interesses dos estudantes.
</p>
			            </div>  
		      </div>						
          </div>	
    
       	
 <!-- JA SLIDESHOW 3 MARK -->
  <div class="maskDesc">
  	<div class="inner">
		
  	</div>
    </div>
  </div>
  <!-- END JA SLIDESHOW 3 MARK -->
    
  <!-- JA SLIDESHOW 3 NAVIAGATION -->
    <div class="ja-slide-thumbs-wrap ja-horizontal">
    <div class="ja-slide-thumbs">
             <div class="ja-slide-thumb">
      	          	<div  class="ja-slide-thumb-inner">
			                                  
             <h3>Sobre Hermes
</h3>
                          			</div>
                     </div>
              <div class="ja-slide-thumb">
      	          	<div  class="ja-slide-thumb-inner">
			                                  
             <h3>Quem somos
</h3>
                          			</div>
                     </div>
              <div class="ja-slide-thumb">
      	          	<div  class="ja-slide-thumb-inner">
			                                  
             <h3>Por que nós?
</h3>
                          			</div>
                     </div>
              <div class="ja-slide-thumb">
      	          	<div  class="ja-slide-thumb-inner">
			                                  
             <h3>Faça parte!
</h3>
                          			</div>
                     </div>
      							
    </div>
	
    <div class="ja-slide-thumbs-mask" style=" display:none ">
    	<div class="ja-slide-thumbs-mask-left">&nbsp;</div>
        <div class="ja-slide-thumbs-mask-center">&nbsp;</div>
        <div class="ja-slide-thumbs-mask-right">&nbsp;</div>
    </div>

    <p class="ja-slide-thumbs-handles">
             <span>&nbsp;</span>
              <span>&nbsp;</span>
              <span>&nbsp;</span>
              <span>&nbsp;</span>
          </p>
 	<!-- JA SLIDESHOW 3 NAVIAGATION -->
        
  </div>
    <!-- JA SLIDESHOW 3 BUTTONS CONTROL -->
    <div class="box tl"></div>
  <div class="box tr"></div>
  <div class="box bl"></div>
  <div class="box br"></div>
  <div class="sl-deco"></div>
</div>

<script type="text/javascript">
    new JASlideshow2('ja-slide-articles-88', {	
                startItem: 0,
                showItem: 4,
                itemWidth: 205,
                itemHeight: 72,
                mainWidth: 940,
                mainHeight: 340,
				maskWidth: 940,
				maskHeigth:340,
                duration: 400,
                transition: Fx.Transitions.Quad.easeInOut,
                animation: 'fade',
				animationRepeat: 'true',
                thumbOpacity:0.8,			
                maskOpacity: 1,
                buttonOpacity: 0.4,
                showDesc: 'desc',
                descMode: 'always',
                readmoretext: 'More info',
                overlap: 0,
                navigation:'thumbs',
				autoPlay: 0,
				interval: 5000,
				showbtncontrol:0,
				maskAlignment:'top',
				languageDirection:( typeof JA_LANGUAGE_DIRECTION == 'string') ? JA_LANGUAGE_DIRECTION : '',
				maskerTransStyle:'opacity',
				maskerTrans:Fx.Transitions.linear,
				navePos:'horizontal'
     });
	/* fix navigator on ie 6,7*/
		 $E('.ja-articles .ja-slide-thumbs-handles').setStyles( {'opacity':'0.001', 'background':'#FFF'} );
</script>	
		</div>
    </div>
	
</div>

	
		<div class="ja-container-inner clearfix">
	
			<div id="ja-mainbody" style="width:67%">
				<!-- CONTENT -->
<div id="ja-main" style="width:100%">
<div class="inner clearfix">
	
	

		<div class="ja-mass ja-mass-top clearfix">
			<div class="ja-moduletable moduletable color2  clearfix" id="Mod106">
						<h3><span>Ultimas adições</span></h3>
				<div class="ja-box-ct clearfix">
			 <script type="text/javascript">
		//<!--[CDATA[
		function contentSliderInit () {
			var container =  $('ja-contentslider-106'); 		
			var options={
				w: 594,
				h: 140,
				num_elem: 1,
				mode: 'horizontal', //horizontal or vertical
				direction: 'left', //horizontal: left or right; vertical: up or down
				total: 6,
				url: 'http://www.movimentohermes.com.br/modules/mod_ja_contentslide/mod_ja_contentslide.php',
				wrapper:  container.getElement("div.ja-contentslider-center"),
				duration: 1000,
				interval: 5000,
				modid: 106,
				running: false,
				auto: 1			};		
			
			var jscontentslider = new JS_ContentSlider( options ); 
			
			var elems = container.getElement(".ja-contentslider-center").getElementsByClassName ('content_element');
			for(i=0;i<elems.length;i++){ 
				jscontentslider.update (elems[i].innerHTML, i);
			}
			jscontentslider.setPos(null);
			if(jscontentslider.options.auto){
				jscontentslider.nextRun();
			}
							container.getElement(".ja-contentslide-left-img").onmouseover = function(){setDirection('left',0, jscontentslider);};
				container.getElement(".ja-contentslide-left-img").onmouseout = function(){setDirection('left',1, jscontentslider);};
				container.getElement(".ja-contentslide-right-img").onmouseover = function(){setDirection('right',0, jscontentslider);};
				container.getElement(".ja-contentslide-right-img").onmouseout = function(){setDirection('right',1, jscontentslider);};
				
		}
		
		window.addEvent( 'load', contentSliderInit );
		
		// window.addEvent( 'load', contentSliderInit);
	
		function setDirection(direction,ret, jscontentslider){
			jscontentslider.options.direction = direction;
			if(ret){
			//	$('ja-contentslide-'+direction+'-img').src = 'http://www.movimentohermes.com.br/templates/ja_pyro/images/re-'+direction+'.gif';
				jscontentslider.options.interval = 5000;
				jscontentslider.options.duration = 1000;
				jscontentslider.options.auto = 1;
				jscontentslider.nextRun();
			}
			else{
		///		$('ja-contentslide-'+direction+'-img').src = 'http://www.movimentohermes.com.br/templates/ja_pyro/images/re-'+direction+'-hover.gif';
				jscontentslider.options.interval = 500;
				jscontentslider.options.duration = 500;
				jscontentslider.options.auto = 1;
				jscontentslider.nextRun();
			}
		}
		//]]-->
				//	alert(.innerHTML ) ;
	 </script>
	
		<div id="ja-contentslider-106"  class="ja-contentslider clearfix" >
			
			<div class="ja-contentslide-buttonwrap">
							<div class="ja-contentslider-left"><img class="ja-contentslide-left-img" src="http://www.movimentohermes.com.br/templates/ja_pyro/images/re-left.gif" alt="left direction" title="left direction" /></div>
						
							<div class="ja-contentslider-right"><img class="ja-contentslide-right-img" src="http://www.movimentohermes.com.br/templates/ja_pyro/images/re-right.gif" alt="right direction" title="right direction" /></div>
						</div>

			<div class="ja-contentslider-center-wrap clearfix">
         		 <div class="ja-contentslider-center">
                 				 													<div class="content_element"><div class="inner">
							
																	<div class="ja_slideimages clearfix">
										<a href="/projetos/olimpiadas-sedentarias-do-ceue.html" title=""></a>									</div>
																
																	<div class="ja_slidetitle">
										<a href="/projetos/olimpiadas-sedentarias-do-ceue.html" title="">Olimpíadas sedentárias do CEUE</a>									</div>
																
																	<div class="ja_slideintro">
										Projeto Conceitual
Idealizador(es): Não há um idealizador novo. Este projeto é baseado em ações de antigas gestões, que de 4 ou mais anos atrás
O quê
Realizar ...									</div>
																
																	<div class="ja-slidereadmore">
										<a href="/projetos/olimpiadas-sedentarias-do-ceue.html'" class="readon">[+] Read full story</a>
									</div>
																
							</div></div>
																		<div class="content_element"><div class="inner">
							
																	<div class="ja_slideimages clearfix">
										<a href="/projetos/fliperama-no-ceue.html" title=""></a>									</div>
																
																	<div class="ja_slidetitle">
										<a href="/projetos/fliperama-no-ceue.html" title="">Fliperama no CEUE</a>									</div>
																
																	<div class="ja_slideintro">
										Projeto Conceitual
Idealizador(es): Emerson Rocha Luiz
O quê
Criar do zero, por esforços dos próprios estudantes da Escola de  Engenharia, um Fliperama, tanto como ...									</div>
																
																	<div class="ja-slidereadmore">
										<a href="/projetos/fliperama-no-ceue.html'" class="readon">[+] Read full story</a>
									</div>
																
							</div></div>
																		<div class="content_element"><div class="inner">
							
																	<div class="ja_slideimages clearfix">
										<a href="/projetos/republica-do-ceue.html" title=""></a>									</div>
																
																	<div class="ja_slidetitle">
										<a href="/projetos/republica-do-ceue.html" title="">República do CEUE</a>									</div>
																
																	<div class="ja_slideintro">
										Projeto Conceitual
Idealizador(es):Emerson Rocha Luiz, Leonardo Pitta Klein e Marcos Vinicius Barbosa Ribeiro.
O quê
Fomentar a criação de uma republica de estudant...									</div>
																
																	<div class="ja-slidereadmore">
										<a href="/projetos/republica-do-ceue.html'" class="readon">[+] Read full story</a>
									</div>
																
							</div></div>
																		<div class="content_element"><div class="inner">
							
																	<div class="ja_slideimages clearfix">
										<a href="/projetos/apoio-a-criacao-e-modernizacao-de-laboratorios.html" title=""></a>									</div>
																
																	<div class="ja_slidetitle">
										<a href="/projetos/apoio-a-criacao-e-modernizacao-de-laboratorios.html" title="">Apoio a criação e modernização de laboratórios</a>									</div>
																
																	<div class="ja_slideintro">
										Projeto Conceitual
Idealizador(es): Movimento Hermes
O quê
Através de diversas ações, fomentar de forma efetiva a melhoria dos laboratórios de exatas da UFRGS, em...									</div>
																
																	<div class="ja-slidereadmore">
										<a href="/projetos/apoio-a-criacao-e-modernizacao-de-laboratorios.html'" class="readon">[+] Read full story</a>
									</div>
																
							</div></div>
																		<div class="content_element"><div class="inner">
							
																	<div class="ja_slideimages clearfix">
										<a href="/projetos/resumo-das-acoes-de-do-movimento-hermes-na-escola-de-engenharia.html" title=""></a>									</div>
																
																	<div class="ja_slidetitle">
										<a href="/projetos/resumo-das-acoes-de-do-movimento-hermes-na-escola-de-engenharia.html" title="">Resumo das ações de do Movimento Hermes na Escola de Engenharia</a>									</div>
																
																	<div class="ja_slideintro">
										[#mhee] Resumo das ações de do Movimento Hermes na Escola de Engenharia
Diretoria Acadêmica
[#saieng] Semana Acadêmica Integrada da Engenharia
Em parceria com subc...									</div>
																
																	<div class="ja-slidereadmore">
										<a href="/projetos/resumo-das-acoes-de-do-movimento-hermes-na-escola-de-engenharia.html'" class="readon">[+] Read full story</a>
									</div>
																
							</div></div>
																		<div class="content_element"><div class="inner">
							
																	<div class="ja_slideimages clearfix">
										<a href="/projetos/ceue-apoia-teu-subcentro.html" title=""></a>									</div>
																
																	<div class="ja_slidetitle">
										<a href="/projetos/ceue-apoia-teu-subcentro.html" title="">CEUE Apóia Teu Subcentro</a>									</div>
																
																	<div class="ja_slideintro">
										Projeto Conceitual
Idealizadores: Emerson Luiz Rocha e Leonardo Pitta Klein
O quê
É dever do CEUE dar condições para que os Subcentros possam operar corretamente. ...									</div>
																
																	<div class="ja-slidereadmore">
										<a href="/projetos/ceue-apoia-teu-subcentro.html'" class="readon">[+] Read full story</a>
									</div>
																
							</div></div>
											</div>
				</div>

	</div>	
		</div>
    </div>
	
	</div>
	
	<div id="ja-contentwrap" class="">
				<div id="ja-content" class="column" style="width:100%">

			<div id="ja-current-content" class="column" style="width:100%">
								
								<div class="ja-content-main clearfix">
					
<h1 class="componentheading">
	Chapa 1 do CEUE: Hermes</h1>

<div class="blog">

			<div class="leading clearfix">
			

<div class="contentpaneopen  clearfix">


<div class="article-main">
<h2 class="contentheading">
			O que já fizemos pelo CEUE em 2009~2010	</h2>


<div class="article-tools clearfix">

	<div class="article-meta">

		<span class="createdate">
		01 Dezembro 2010	</span>
	
	
		</div>

	
	
</div>


<div class="article-content">
<div align="center"><object width="600" height="360"><param name="movie" value="http://www.youtube.com/v/qvTyRdRHjJw?fs=1&amp;hl=pt_BR&amp;color1=0x006699&amp;color2=0x54abd6"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/qvTyRdRHjJw?fs=1&amp;hl=pt_BR&amp;color1=0x006699&amp;color2=0x54abd6" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="600" height="360"></embed></object></div>
<p></p>
<p> Comprove você mesmo que as ações ditas no video e outras mais realmente ocorreram feitas pela Hermes:<br />
<a href="http://www.movimentohermes.com.br/acoes/realizadas.html" target="_blank">http://www.movimentohermes.com.br/acoes/realizadas.html</a></p>
<p>Para uma visão geral de todos os projetos, veja <a href="http://www.movimentohermes.com.br/tudo" target="_blank">http://www.movimentohermes.com.br/tudo</a></p>
<p>&nbsp;</p></div>


</div>

</div>

		</div>
			<div class="leading clearfix">
			

<div class="contentpaneopen  clearfix">


<div class="article-main">
<h2 class="contentheading">
			Resumo das ações de do Movimento Hermes na Escola de Engenharia	</h2>


<div class="article-tools clearfix">

	<div class="article-meta">

		<span class="createdate">
		12 Novembro 2010	</span>
	
	
		</div>

	
	
</div>


<div class="article-content">
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=mhee" target="_blank">#mhee</a>] Resumo das ações de do Movimento Hermes na Escola de Engenharia</h3>
<h2>Diretoria Acadêmica</h2>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=saieng" target="_blank">#saieng</a>] <a href="/projetos/semana-academica-integrada-da-engenharia.html">Semana Acadêmica Integrada da Engenharia</a></h3>
<p style="padding-left: 30px;">Em parceria com subcentros, dar suporte total para organização da semana acadêmica de cada um, além de viabilizar palestras ou outros eventos genéricos, interessantes a qualquer engenharia, e divulgar de forma fácil todos os eventos, mantendo um calendário único de divulgação das atividades.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=pameng" target="_blank">#pameng</a>] <a href="/projetos/programa-de-apoio-a-mobilidade-entre-engenharias.html">Programa de apoio a mobilidade entre Engenharias</a></h3>
<p style="padding-left: 30px;">Catalogar e divulgar o que já existe para troca de alunos interessados em trocar de curso entre engenharias e, em um segundo momento, viabilizar uma facilitação disto, além de integrar um programa de conscientização da função de cada engenharia.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=gruposdeestudoceue" target="_blank">#gruposdeestudoceue</a>] <a href="/projetos/grupos-de-estudos-ceue.html" target="_blank">Grupos de Estudos CEUE</a></h3>
<p style="padding-left: 30px;">Usar salas de aulas ociosas da Escola de Engenharia  em tarde/noites anteriores de certas disciplinas comuns na engenharia (e as com maior indice de repetencia) para estimular a formação de <strong>grupos de estudo</strong> de alunos interessados, com apoio de material de suporte (listas de excercicios, livros, provas anteriores...), ajuda de colaboradores espontâneos e, ainda que seja fácil conseguir ajuda dos monitores das disciplinas, focar em grupos de estudo, não monitoria.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=feeng" target="_blank">#feeng</a>] <a href="/projetos/fomento-a-encontro-de-estudantes-de-engenharia.html" target="_blank">Fomento a encontro de estudantes de engenharia</a></h3>
<p style="padding-left: 30px;">Viabilizar, através de organização interna e catalogação destas informações, encontro de estudantes regionais ou nacionais, bem como facilitar o transporte a estes eventos quando não forem em Porto Alegre.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=rdceue" target="_blank">#rdceue</a>] <a href="/projetos/rodada-de-debates.html">Rodada de debates do CEUE</a></h3>
<p style="padding-left: 30px;">Como forma de incitar os alunos a debaterem sobre assuntos correntes em engenharia, a rodada de debates tem como objetivo trazer atualidades da engenharia, fazer os alunos trabalharem sua comunicação e, consequentemente, melhor sua forma de agir em grupo.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceueajudaaescolherteucurso" target="_blank">#ceuemelhoriadelaboratorios]</a> <a href="/projetos/apoio-a-criacao-e-modernizacao-de-laboratorios.html" target="_blank">Apoio a criação e modernização de laboratórios</a><a href="/projetos/apoio-a-criacao-e-modernizacao-de-laboratorios.html" target="_blank"></a></h3>
<p style="padding-left: 30px;">É de grande importância ter bons laboratórios na engenharia. Trazendo um pensamento antigo, recorrente do início da Escola de Engenharia, visamos a melhoria e a criação de novos laboratórios para a engenharia, por meio de parcerias internas pela alocação de recursos da UFRGs e por parcerias externas, na montagem de laboratórios profissionais.</p>
<h2>Diretoria de Integração</h2>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=recepcaodosbixosdaee" target="_blank">#recepcaodosbixosdaee</a>] <a href="/projetos/recepcao-dos-calouros-da-escola-de-engenharia.html" target="_blank">Recepção dos Calouros da Escola de Engenharia</a></h3>
<p style="padding-left: 30px;">Receber e dar todo o suporte aos novos alunos da Escola de Engenharia, instruindo sobre moradia, festas, escolha das disciplinas e outras informações básicas para a sobrevivência na UFRGS.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceueteintegra" target="_blank">#ceueteintegra</a>] <a href="/projetos/ceue-te-integra.html">CEUE Te Integra</a></h3>
<p style="padding-left: 30px;">Reúne ações referentes a integração das pessoas. Campeonatos, festas, manutenção e melhoramento da sala de jogos, e afins.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceuerockfestival" target="_blank">#ceuerockfestival</a>] <a href="/projetos/ceue-rock-festival.html">CEUE Rock Festival</a></h3>
<p style="padding-left: 30px;">Circuito de festas com intuito de abrir espaço para as bandas formadas na universidade, culminando no vendo do prêmio Engenharia Rocks!</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=olimpiadassedencatiasceue" target="_blank">#olimpiadassedencatiasceue</a>] <a href="/projetos/olimpiadas-sedentarias-do-ceue.html">Olimpíadas sedentárias do CEUE</a></h3>
<p style="padding-left: 30px;">Continuação das tradicionais Olimpíadas Sedentárias do CEUE, aonde esportes sedentáriamente olímpicos são praticados! Desde sinuca ao às extremamente agitado ping-pong!</p>
<h2>Diretoria de Marketing e Relações Institucionais</h2>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceueapoiateusubcentro" target="_blank">#ceueapoiateusubcentro</a>] <a href="/projetos/ceue-apoia-teu-subcentro.html">CEUE Apoia Teu Subcentro</a></h3>
<p style="padding-left: 30px;">Colaborar e integrar ações úteis aos subcentros. É extremamente vital que, além de trabalhar para os estudantes, o CEUE esteja a serviço dos Subcentros em colaboração constante.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=gcmeengbr" target="_blank">#gcmeengbr</a>] <a href="/projetos/gerenciamento-de-contatos-com-cas-e-das-de-engenharia-do-brasil.html">Gerenciamento de contatos com CAs e DAs de Engenharia do Brasil</a></h3>
<p style="padding-left: 30px;">Descobrir, catalogar e divulgar dados de contato de centros e diretórios acadêmicos de engenharias do Brasil, de modo a servir de suporte a facilitação de troca de informações e ajudas entre o movimento estudantil, e viabilizar outros projetos com maior facilidade, como os encontros de estudantes.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceueteemprega" target="_blank">#ceueteemprega</a>] <a href="/projetos/ceue-te-emprega.html">CEUE Te Emprega</a></h3>
<p style="padding-left: 30px;">Obter e divulgar empregos, estágios, concursos públicos e bolsas para alunos e ex-alunos da Escola de Engenharia.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=riisceue" target="_blank">#riisceue</a>] <a href="/projetos/relacoes-institucionais-industriais-e-sindicais-do-ceue.html" target="_blank">Relações Institucionais, Industriais e Sindicais do CEUE</a></h3>
<p style="padding-left: 30px;">Manter e cultivar uma boa relação com entidades inter-dependentes da formação em engenharia, com objetivo de viabilizar os projetos e as ações que estamos propondo.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceueajudaaescolherteucurso" target="_blank">#ceueajudaaescolherteucurso</a>] <a href="/projetos/ceue-ajuda-a-escolher-teu-curso.html" target="_blank">CEUE ajuda a escolher teu curso</a></h3>
<p style="padding-left: 30px;">Projeto de extensão que visa divulgar o que é engenharia, diferenças para os demais   cursos, e para os respectivos cursos, como meio de fomentar a entrada de   alunos conscientes do que querem escolher no vestibular.  Por meios de visitas e palestras para alunos de ensino médio e profissionalizante, conscientizar a profissão também dentro da própria universidade, como parte do <a href="/projetos/programa-de-apoio-a-mobilidade-entre-engenharias.html">Programa de apoio a mobilidade entre Engenharias</a>.</p>
<h2>Diretoria Social</h2>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceueapoiatuamoradia" target="_blank">#ceueapoiatuamoradia</a>] <a href="/projetos/ceue-apoia-tua-moradia.html">CEUE apóia tua moradia</a></h3>
<p style="padding-left: 30px;">Projeto que visa divulgar, em especial aos calouros, diversas possibilidades de moradia e colaborar para facilitar a moradia em conjunto com colegas, além de ver meios de logística e provável apoio financeiro de colaboradores para custear a manutenção de casas de estudantes sem fins lucrativos aonde alunos da escola de engenharia estiverem (CEUPA, CEUACA, JUC7 e afins).</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=republicadoceue" target="_blank">#republicadoceue</a>] <a href="/projetos/republica-do-ceue.html" target="_blank">República do CEUE</a></h3>
<p style="padding-left: 30px;">Fomentar a criação de uma república de estudantes da Escola de Engenharia, gerenciada pelos moradores, quer seja em primeiro momento através de espaço físico alugado ou comprado, quer seja mais tarde em realmente trabalhar para contruir do zero um prédio.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=rpee" target="_blank">#rpee</a>] <a href="/projetos/resgate-do-passado-da-escola-de-engenhariaresgate-do-passado-da-escola-de-engenharia.html" target="_blank">Resgate do Passado da Escola de Engenharia</a></h3>
<p>Descobrir, catalogar e divulgar amplamente o passado da Escola de Engenharia e do CEUE, para dar base aos estudantes, professores e servidores de hoje de onde viemos, e, com respeito ao passado, se perguntar: para aonde queremos ir?</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=csaee" target="_blank">#csaee</a>] <a href="/projetos/conscientizacao-social-de-alunos-da-escola-de-engenharia.html" target="_blank">Conscientização Social de Alunos da Escola de Engenharia</a></h3>
<p style="padding-left: 30px;">Reunir ações de fomento a conscientização social dos estudantes, em respeito a sociedade em que vivemos.</p>
<h2>Diretoria de Projetos</h2>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=apceue" target="_blank">#apceue</a>] <a href="/projetos/apoio-a-novos-projetos-do-ceue.html" target="_blank">Apoio a novos projetos do CEUE</a></h3>
<p style="padding-left: 30px;">Reunir um modo de agir padrão para apoiar qualquer novo projeto, de modo que qualquer nova ação tenha apoio para viabilidade prática e financeira, além de ser encaminhada para demais pessoas interessadas para sua realização.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=oficinadeprojetos" target="_blank">#oficinadeprojetos</a>] <a href="/projetos/oficina-de-projetos.html" target="_blank">Oficina de Projetos</a></h3>
<p style="padding-left: 30px;">Prover meios de a criatividade dos estudantes, em especial de exatas da UFRGS, com apoio, mas não sob direção de professores, tenham infraestrutura, ferramentas e algum apoio financeiro contrução de protótipos, além de promover uma estreita relação entre o mercado de trabalho com o que é desenvolvido na Oficina de Projetos, como meio de dar visibilidade aos participantes e garantir-lhes que, com boas ideias, seu emprego estará garantido antes mesmo de se formar.</p>
<h3>[<a href="http://search.twitter.com/search?q=%E2%8C%A9=pt&tag=fliperamanoceue" target="_blank">#fliperamanoceue</a>] <a href="/projetos/fliperama-no-ceue.html" target="_blank">Fliperama no CEUE</a></h3>
<p style="padding-left: 30px;">Criar do zero, por esforços dos próprios estudantes da Escola de Engenharia, um Fliperama, tanto como estimulo a criatividade, como para a diversão dos alunos que frequentam o CEUE.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=dsceue" target="_blank">#dsceue</a>] <a href="/projetos/desenvolvimento-de-software.html" target="_blank">Desenvolvimento de Software do CEUE</a></h3>
<p style="padding-left: 30px;">Tendo em vista que o programa da Hermes é focado no gerenciamento de informações, este projeto visa reunir ações para desenvolvimento de tecnologia própria para organização destas ações.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=graficadoceue" target="_blank">#graficadoceue</a>] <a href="/projetos/grafica-do-ceue.html">Gráfica do CEUE</a></h3>
<p style="padding-left: 30px;">Reativar a histórica gráfica do CEUE, para servir tanto como fonte de renda, como uma importante aliada aos interesses da entidade, focada na utilidade junto aos estudantes de engenharia e da própria UFRGS, porém de modo que fique sob direção do CEUE, para sempre.</p>
<h2>Secretaria Unificada</h2>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=frceue" target="_blank">#frceue</a>] <a href="/projetos/fontes-de-renda-do-ceue.html">Fontes de Renda do CEUE</a></h3>
<p style="padding-left: 30px;">Otimizar as fontes de rendas existentes, e procurar novas fontes, focado em desonerar ao máximo o próprio estudante da Escola de Engenharia, e viabilizar que tais retornos além de financeiros a entidade, sejam obtidos por ações que gerem conhecimento e experiência técnica aos participantes, util mais tarde na vida profissional.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=rgceue" target="_blank">#rgceue</a>] <a href="/projetos/relatorias-de-gestao-do-ceue.html">Relatorias de Gestão do CEUE</a></h3>
<p>Como meio de tornar claro o processo de gestão, as relatorias são a forma mais precisa de que os estudantes estejam inteirados do que está acontecendo em seu Centro Acadêmico.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=gpsceue" target="_blank">#gpsceue</a>] <a href="/projetos/gerenciamento-de-prestadores-de-servico-do-ceue.html" target="_blank">Gerenciamento de Prestadores de Serviço do CEUE</a></h3>
<p style="padding-left: 30px;">Gerenciar de forma relativamente publica a relação com prestadores de produtos e serviços, de modo que, pela divulgação e troca de informações com parceiros, sempre tenha-se os mais baratos e eficientes prestadores, e estes, ao verem que ao ser bons prestadores atingem uma rede de compradores maior, melhorem e até barateiem seus preços.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=wikigme" target="_blank">#wikigme</a>] <a href="/projetos/divulgacao-de-gerenciamento-de-entidades-academicas.html">Wiki GME: Divulgação de Gerenciamento de Entidades Acadêmicas</a></h3>
<p style="padding-left: 30px;">Continuar o bom serviço iniciado na wiki <a href="http://www.gme.ceue.eng.br/" target="_blank">http://www.gme.ceue.eng.br/</a>, que consistem descobrir, catalogar e divulgar informações de como gerenciar uma entidade acadêmica, com informações de organização interna, de eventos, legislação aplicável, fontes de renda e muito mais. É uma wiki, idealizada e mantida pela Hermes que visa o melhoramento em nível nacional de CAs e DAs, além de garantir que as próximas gestões do CEUE saibam como nós fizemos, e garantir que não haja mais gestões medíocres.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=caee" target="_blank">#caee</a>] <a href="/projetos/cadastro-dos-alunos-e-ex-alunos-da-escola-de-engenharia.html" target="_blank">Cadastro dos Alunos e Ex-alunos da Escola de Engenharia</a></h3>
<p style="padding-left: 30px;">Descobrir, catalogar e publicar a lista de ex-alunos da Escola de Engenharia, ver meios de deixar claro aqueles que deixaram sua marca na história e, aos que ainda estão vivos, fomentar encontros de turmas e a criação de um anuário de alunos online.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=gceceue" target="_blank">#gceceue</a>] <a href="/projetos/gerenciamento-de-contatos-externos-do-ceue-e-subcentros.html" target="_blank">Gerenciamento de Contatos Externos do CEUE e Subcentros</a></h3>
<p style="padding-left: 30px;">Obter, catalogar e gerenciar contatos externos e manter uma estreita relação com subcentros, como meio de fomentar a troca de informações, em especial do CEUE para o subcentro. Tais contatos ajudarão desde obtenção de palestrantes para eventos, até mesmo doadores, em especial aqueles que estiverem no cadastro de Alunos e Ex-alunos da Escola de Engenharia gerenciado pelo CEUE.</p>
<h2>Presidência</h2>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceuepvp" target="_blank">#ceuepvp</a>] <a href="/projetos/ceue-pre-vestibular-popular.html">CEUE Pré-vestibular Popular</a></h3>
<p style="padding-left: 30px;">Através da experiência em 2009, otimizar o funcionamento do Pré-vestibular mantido pelo CEUE, e atacar de forma incisiva os maisores problemas, em especial a confecção de material didático, a falta de professores e afins.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceueatpvp" target="_blank">#ceueatpvp</a>] <a href="/projetos/ceue-apoia-teu-pre-vestibular-popular.html">CEUE Apoia Teu Pré-vestibular Popular</a></h3>
<p style="padding-left: 30px;">Usar a mesma lógica aplicada na organização interna do CEUE Pré-vestibular para, em parceria com outros pré-vestibulares da região, em especial os vinculados a estudantes da UFRGS, viabilizar meios de ajuda mútua, em especial na padronização de material didárico, divulgação, e fontes de rendas alternativas.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=ceuepdme" target="_blank">#ceuepdme</a>] <a href="/projetos/ceue-procura-os-direitos-do-movimento-estudantil.html" target="_blank">CEUE procura os direitos do Movimento Estudantil</a></h3>
<p style="padding-left: 30px;">Ao ser atuante em 2009, a Hermes percebeu que muito se perde ao não se saber seus direitos. Este projeto visa através descobrir até aonde o estudante tem direito frente a professores e a instituições de ensino, além de em especial ver o que centros e diretórios acadêmicos podem fazer e garantir sua autonomia.</p>
<h3>[<a href="http://search.twitter.com/search?q=&lang=pt&tag=jornaldoceue" target="_blank">#jornaldoceue</a>] <a href="/projetos/jornal-do-ceue.html" target="_blank">Jornal do CEUE</a></h3>
<p style="padding-left: 30px;">Divulgar as ações tomadas na Escola de Engenharia, novidades no mundo da Engenharia, problemas a serem solucionados e divulgar as ações que estão sendo tomadas em nome doe estudantes.</p></div>


</div>

</div>

		</div>
	
	
	
	</div>

				</div>
				
								
				
			</div>

			
		</div>
		
			</div>

	
</div>
</div>
<!-- //CONTENT -->							</div>

			<!-- RIGHT COLUMN--> 
<div id="ja-right" class="column sidebar" style="width:33%">

	
		<div class="ja-colswrap clearfix ja-r1">

	
			<div class="ja-col  column" style="width:100%">
				<div class="ja-moduletable moduletable  clearfix" id="Mod117">
						<div class="ja-box-ct clearfix">
		<ul class="menu"><li class="item162"><a href="https://www1.ufrgs.br/eleicoes/ELeicoesUfrgs.php?CodConcurso=168"><span>Clique Aqui Para votar</span></a></li></ul>		</div>
    </div>
		<div class="ja-moduletable moduletable  clearfix" id="Mod67">
						<h3><span>O que estamos fazendo?</span></h3>
				<div class="ja-box-ct clearfix">
		<div class="ja-twitter">
		
	<!-- ACCOUNT INFOMATION -->
		<!-- // ACCOUNT INFOMATION -->
	
	<!-- LISTING FRIENDS -->
		<!-- //LISTING FRIENDS -->
	
	<!-- LISTING TWEETS -->
		
	<div class="ja-twitter-tweets">
	
				<div class="ja-twitter-item">
						
						
			<div class="ja-twitter-text">
							    <a href="http://twitter.com/MovimentoHermes" target="_blank">Movimento Hermes</a>
									
				Hoje foi um bom dia para cativar simpatizantes. Não são muitos os que se comprometem, mas os que o fazem, são de fé <a target="_blank" href="http://twitter.com/search?q=#mhee" >mhee</a>			</div>
			<div class="ja-twitter-date" style="">
				Sáb, 20 de Novembro de 2010 06:29			</div>
		</div>
				<div class="ja-twitter-item">
						
						
			<div class="ja-twitter-text">
							    <a href="http://twitter.com/MovimentoHermes" target="_blank">Movimento Hermes</a>
									
				Amanhã, Sábado 20/11 aqui no CEUE, estaremos tocando o <a target="_blank" href="http://twitter.com/search?q=#fliperamanoceue" >fliperamanoceue</a> via <a target="_blank" href="http://twitter.com/search?q=#oficinadeprojetos" >oficinadeprojetos</a> <a href="http://goo.gl/QToAl" >http://goo.gl/QToAl</a>			</div>
			<div class="ja-twitter-date" style="">
				Sex, 19 de Novembro de 2010 20:49			</div>
		</div>
				<div class="ja-twitter-item">
						
						
			<div class="ja-twitter-text">
							    <a href="http://twitter.com/MovimentoHermes" target="_blank">Movimento Hermes</a>
									
				Opa! Pelo menos um interessado na criação do <a target="_blank" href="http://twitter.com/search?q=#republicadoceue" >republicadoceue</a> enviou email! :D			</div>
			<div class="ja-twitter-date" style="">
				Qua, 17 de Novembro de 2010 19:31			</div>
		</div>
			</div>
		
	<!-- //LISTING TWEETS -->
	
		<center>
		<img alt="twitter" src="http://www.movimentohermes.com.br/modules/mod_jatwitter/assets/images/twitter-16x16.png" align="left"/>
		<a href="http://twitter.com/MovimentoHermes/" target="_blank" title="Follow MovimentoHermes on Twitter">
			<span>Follow MovimentoHermes on Twitter</span>
		</a>
	</center>
	</div>		</div>
    </div>
		<div class="ja-moduletable moduletable_blank  clearfix" id="Mod83">
						<div class="ja-box-ct clearfix">
				</div>
    </div>
		<div class="ja-moduletable moduletable  clearfix" id="Mod116">
						<h3><span>Acompanhe Hermes</span></h3>
				<div class="ja-box-ct clearfix">
		<p>Twitter: <a href="http://twitter.com/MovimentoHermes" target="_blank">@MovimentoHermes</a><br />Orkut: <a href="http://www.orkut.com.br/Main#Profile?uid=17471945806969431812" target="_blank">Movimento Hermes</a><br />Email: contato@movimentohermes.com.br</p>		</div>
    </div>
	
		</div>
	
	</div>
	
	
</div>
<!-- RIGHT COLUMN--> 
		</div>
	
	</div>
	</div></div></div>
	<div class="ja-rs-bot"><div class="ja-rs-bl">&nbsp;</div><div class="ja-rs-br">&nbsp;</div></div>
	
	</div>
	</div>
	<!-- //MAIN CONTAINER -->
	
	
	
	<!-- FOOTER -->
	<div id="ja-footer" class="wrap">
<div class="main clearfix">

<div class="ja-footnav">
	<ul id="mainlevel-nav"><li><a href="http://www.ceue.eng.br" class="mainlevel-nav" >CEUE</a></li><li><a href="http://sites.google.com/site/comissaoeleitoralceue/" class="mainlevel-nav" >Comissão Eleitoral</a></li><li><a href="http://www.ufrgs.br/eng/" class="mainlevel-nav" >Escola de Engenharia</a></li><li><a href="http://ufrgs.br" class="mainlevel-nav" >UFRGS</a></li><li><a href="/login.html" class="mainlevel-nav" >Login neste site</a></li></ul>    
    <ul class="ja-links">
		<li class="layout-switcher">&nbsp;</li>
		<li class="top"><a href="/index.php#Top" title="Back to Top">Top</a></li>
	</ul>
</div>
	
<div class="inner">
	<div class="ja-copyright">
		<small>Copyright &#169; 2010 Chapa 1 do CEUE: Hermes. Todos os direitos reservados.<br /> Designed by <a href="http://www.joomlart.com/" title="Visit Joomlart.com!">JoomlArt.com</a>.</small>
<small><a href="http://www.joomla.org">Joomla!</a> é um Software Livre com <a href="http://www.gnu.org/licenses/gpl-2.0.html">licença GNU/GPL v2.0</a>.</small>
	</div>
	<div id="ja-poweredby">
		<a id="t3-logo" href="http://t3.joomlart.com" title="Powered By T3 Framework" target="_blank">Powered By T3 Framework</a>
	</div>
</div>

</div>
</div>	<!-- //FOOTER -->

</div>




</body>

</html>
